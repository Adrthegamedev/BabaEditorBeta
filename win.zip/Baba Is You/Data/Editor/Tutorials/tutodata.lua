tutodata =
{
}

dofile("Data/Editor/Tutorials/tuto1.lua")
dofile("Data/Editor/Tutorials/tuto2.lua")
dofile("Data/Editor/Tutorials/tuto3.lua")
dofile("Data/Editor/Tutorials/tuto4.lua")
dofile("Data/Editor/Tutorials/tuto5.lua")
dofile("Data/Editor/Tutorials/tuto6.lua")
dofile("Data/Editor/Tutorials/tuto7.lua")
dofile("Data/Editor/Tutorials/tuto8.lua")
dofile("Data/Editor/Tutorials/tuto9.lua")
dofile("Data/Editor/Tutorials/tuto10.lua")